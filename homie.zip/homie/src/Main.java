import javax.swing.*;
public class Main {

    public static void main(String[] args){
        String choice = JOptionPane.showInputDialog( null,
                "How's your today's birthday?", "Hi!^^",JOptionPane.QUESTION_MESSAGE);
        if(choice.equals("Great")){
            JOptionPane.showMessageDialog(null,
                    "\n " + "GOOODDDD!!","^^",JOptionPane.QUESTION_MESSAGE);
        }
        String choice2 = JOptionPane.showInputDialog( null,
                "So, did you enjoy your day today?", ":)?", JOptionPane.QUESTION_MESSAGE);
        if(choice2.equals("Yes")){
            JOptionPane.showMessageDialog(null,
                    "\n" + "Thats great to hear! ^^", "^^", JOptionPane.QUESTION_MESSAGE);
        }
        String choice3 = JOptionPane.showInputDialog( null,
                "\n" + "Pero sure ka?", ":/?", JOptionPane.QUESTION_MESSAGE);
        if(choice3.equals("Oo")) {
            JOptionPane.showMessageDialog(null, "\n" + "That's great to hear from you!^^", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Hopefully na happy and enjoy ka sa imong birthday karun :)", "XD", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "I enjoyed also being with you earlier to be honest","^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "I know this message for you isn't that long enough but", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null,"\n" +
                    "I want you to remind that","•.•", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null,"\n" +
                    "Im here for you :)","^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Always and Anytime", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null,"\n" +
                    "We Shared a lot of stories, memories and experiences", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "That'll always treasure and will cherish till my time is over", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "I wish you nothing but the absolute best for this new chapter of your life :)", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "May your dreams will continue to come true", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "and more happiness and success will come through your life:)", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "and besides all of these, ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "i want you to keep going :) ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "i know that you're struggling but ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "whatever is going on, ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "you totally got this! ^^ ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Because ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "you're such an amazing person that i've ever met before :) ", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "You deserve all the love and happiness as I saw in your eyes", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "don't rush for something that isn't good and fits for you", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "and", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Make sure na pasado ka sa imong exam", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "and once again,", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Happy Birthday my dearest Nicole^^", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "May this day be filled with joy, laughter and unforgettable moments in each other's companies :)", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "With all my wishes,", "^^", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "Hoping our friendship wont end", ":)", JOptionPane.QUESTION_MESSAGE);

            JOptionPane.showMessageDialog(null, "\n" +
                    "- gen ^^", "^^", JOptionPane.QUESTION_MESSAGE);
        }
    }
}